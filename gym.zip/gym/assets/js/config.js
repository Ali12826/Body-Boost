const firebaseConfig = {
    apiKey: "AIzaSyCcq7JLrVDYzithyMwGHH3MVLlzIlcVuy4",
    authDomain: "pushnotifcation-d13d6.firebaseapp.com",
    projectId: "pushnotifcation-d13d6",
    storageBucket: "pushnotifcation-d13d6.appspot.com",
    messagingSenderId: "1033174233346",
    appId: "1:1033174233346:web:b68a7be80045cc42df521b"
};
export { firebaseConfig };